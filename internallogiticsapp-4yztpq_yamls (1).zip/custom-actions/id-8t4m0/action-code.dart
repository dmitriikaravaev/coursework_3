Future<bool> newCustomAction(
  String? textField,
) async {
  // validation for phone number by pressing button

  // Regular expression to validate phone number
  RegExp regex = RegExp(r'^\+7\(\d{3}\)\d{3}-\d{2}-\d{2}$');

  // Check if the input matches the regular expression
  if (regex.hasMatch(textField!)) {
    // If the input is valid, return true
    return true;
  } else {
    // If the input is invalid, show an error message and return false
    print('Invalid phone number');
    return false;
  }
}